#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from collections import defaultdict
from googletrans import Translator
import pandas as pd


# In[ ]:


translator = Translator()


# In[ ]:


def build_ref_lang_byIP_dict(): 
    english_IPs = ["nyc1"]     
    dutch_IPs = ["ams3"]
    German_IPs = [ "fra1"]
    Bangalore_IPs = ["blr1"]
    Singapore_IP = ["sgp1"]
    
    all_IPs = ["nyc1", "ams3", 
               "fra1", "blr1","sgp1"]
    
    ref_lang_byIP = defaultdict(dict)
    
    for IP in all_IPs: 
        if IP in english_IPs: 
            ref_lang_byIP[IP]=dict()
            ref_lang_byIP[IP]['English']= "en"
        if IP in dutch_IPs: 
            ref_lang_byIP[IP]=dict()
            ref_lang_byIP[IP]['Dutch']= "nl"
        if IP in German_IPs: 
            ref_lang_byIP[IP]=dict()
            ref_lang_byIP[IP]['German']= "de"
        if IP in Bangalore_IPs: 
            ref_lang_byIP[IP]=dict()
            ref_lang_byIP[IP]['Punjabi']= "pa"
            ref_lang_byIP[IP]['Urdu']= "ur"
        if IP in Singapore_IP: 
            ref_lang_byIP[IP]=dict()
            ref_lang_byIP[IP]['Malay']= "ms"
            ref_lang_byIP[IP]['Chinese']= "zh-CN"
            
    return ref_lang_byIP


# In[ ]:


def translation_dict_to_df(search_terms, translation_dict, domain):
    col_names =  ['datacenter', 'language', 'search_term', 
                  'eng_term', 'domain'] 
    
    trans_df  = pd.DataFrame(columns = col_names)

    for term in search_terms: 
        term_dict = translation_dict[term]
        term_df = pd.DataFrame.from_dict({(i, j): [j, term_dict[i][j]]
                                          for i in term_dict.keys() 
                                          for j in term_dict[i].keys()},
                                         orient='index')

        mod_idx = [list(term_df.index)[i][0] for i in range(len(term_df.index))]
        term_df["datacenter"] = mod_idx
        term_df.columns = ['language', 'search_term', 'datacenter']
        term_df['eng_term']=term
        term_df['domain']=domain
        trans_df = trans_df.append(term_df)
    
    return trans_df


# In[ ]:


def get_translations_byIP(term, IP, ref_lang_byIP):    
    translations = dict()
    translations[IP] = dict() 
    
    IP_dict = ref_lang_byIP[IP]
    IP_languages = list(IP_dict.keys())
    
    for IP_language in IP_languages: 
        ref_lang = IP_dict[IP_language]
        translation = translator.translate(term, dest=ref_lang)[0]
        
        translations[IP][IP_language] = translation.text
    
    return translations


# In[ ]:


def get_translations_all_languages(term, IP, ref_lang_noIP):
    
    all_lang_dest = list(ref_lang_noIP.values())
    
    translations = dict()
    translations[IP] = dict() 
    
    for lang_dest in all_lang_dest: 
        translation = translator.translate(term, dest=lang_dest)[0]        
        translations[IP][lang_dest] = translation.text
    
    return translations



# In[ ]:


def get_translations_for_IPs(search_terms, ref_lang_dict, domain):
    IPs=list(ref_lang_dict.keys())
    full_translation_set = dict()
    
    for term in search_terms: 
        full_translation_set[term]=dict()
        for IP in IPs:
            full_translation_set[term][IP] = dict()
            translations = get_translations_byIP(term, IP, ref_lang_dict)
            trans_spec = translations[IP]
            
            for lang in list(trans_spec.keys()):
                full_translation_set[term][IP]= translations[IP]
                
    trans_df = translation_dict_to_df(search_terms,
                                      full_translation_set,
                                      domain)
    
    trans_df["search_term"] = trans_df['search_term'].str.replace('[^\w\s]','')
    
    return trans_df


# In[ ]:


def get_translations_full_lang_IP_sweep(search_terms, 
                                 ref_lang_dict, 
                                 ref_lang_noIP, 
                                 domain):
    
    IPs=list(ref_lang_dict.keys())
    full_translation_set = dict()
    
    for term in search_terms: 
        full_translation_set[term]=dict()
        for IP in IPs:
            full_translation_set[term][IP] = dict()
            translations = get_translations_all_languages(term, IP, 
                                                          ref_lang_noIP)
            
            full_translation_set[term][IP]= translations[IP]
        
    trans_df = translation_dict_to_df(search_terms,
                                      full_translation_set,
                                      domain)
    
    trans_df["search_term"] = trans_df['search_term'].str.replace('[^\w\s]','')
        
    return trans_df

