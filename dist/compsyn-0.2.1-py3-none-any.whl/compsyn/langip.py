#!/usr/bin/env python3
from __future__ import annotations
import argparse
import csv
import time
import random
from pathlib import Path

from googletrans import Translator

langip_regions = ["nyc1", "ams3", "fra1", "blr1", "sgp1"]
langip_languages = {"en": "English", "nl": "Dutch", "de": "German", "ta": "Tamil", "zh-CN": "Chinese (Simplified)"}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True, help="csv with english words and associated metadata")
    args = parser.parse_args()

    root_csv = Path(args.csv)
    if not root_csv.is_file():
        raise FileNotFoundError(f"--csv must point to an existing file, {root_csv} does not exist.")

    csv_dict = csv.DictReader(open(root_csv))

    t = Translator()

    langip_experiment_terms = list()
    for row in csv_dict:
        english_term = row["search_term"]
        row.update({"eng_ref": english_term})
        row.update({"datacenter": " ".join(langip_regions)})
        for language_code, language_name in langip_languages.items():
            row.update({"search_term": t.translate(english_term, dest=language_code).text})
            row.update({"language": language_name})
            time.sleep(random.random() * 5)
            langip_experiment_terms.append(row)
            print(row)

    keys = langip_experiment_terms[0].keys()
    with open("langip_grids_top_100_english_words.csv", "wb") as output_file:
        dict_writer = csv.DictWriter(output_file, keys)
        dict_writer.writeheader()
        dict_writer.writerows(langip_experiment_terms)

